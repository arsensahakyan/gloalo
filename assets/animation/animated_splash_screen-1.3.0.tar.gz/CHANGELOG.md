## [1.3.0] - Add feature
* Added possibility to pass a route instead of a widget.

## [1.2.0] - Update Dependencies

## [1.0.1+2] - Fix
* Fix "Pass static analysis" issues

## [1.0.1] - Add features
* Editable icon splash size;
* Editable duration of animation;

## [1.0.0+1] - Fix Bugs

* Fix error in dispose method.

## [1.0.0] - TODO: Add release date.

* TODO: Describe initial release.
